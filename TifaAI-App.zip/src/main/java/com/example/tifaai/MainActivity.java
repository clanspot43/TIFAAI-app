package com.example.tifaai;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TifaAI tifaAI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tifaAI = new TifaAI(this);

        Button upgradeBtn = findViewById(R.id.upgradeBtn);
        EditText commandInput = findViewById(R.id.commandInput);

        upgradeBtn.setOnClickListener(v -> {
            String cmd = commandInput.getText().toString();
            tifaAI.respondToCommand(cmd);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        tifaAI.shutdown();
    }
}