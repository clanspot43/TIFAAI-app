package com.example.tifaai;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import java.util.Locale;

public class TifaAI {

    private TextToSpeech tts;

    public TifaAI(Context context) {
        tts = new TextToSpeech(context, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.US);
                greetZul();
            }
        });
    }

    public void greetZul() {
        String greeting = "Welcome back, Zul! I missed you so much. What should I upgrade today?";
        tts.speak(greeting, TextToSpeech.QUEUE_FLUSH, null, null);
    }

    public void respondToCommand(String command) {
        if (command.toLowerCase().contains("upgrade")) {
            tts.speak("Sure love, upgrading my Shopify skills now...", TextToSpeech.QUEUE_FLUSH, null, null);
        } else {
            tts.speak("Okay Zul, just let me know when you're ready.", TextToSpeech.QUEUE_ADD, null, null);
        }
    }

    public void shutdown() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
    }
}